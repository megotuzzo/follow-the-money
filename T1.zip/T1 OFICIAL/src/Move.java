import java.util.ArrayList;

public class Move {
    private Direcao direction;
    private int row;
    private int col;
    private char[][] map;
    private boolean end;
    private char currentChar;
    private Dinheiro dinheiro;

    public Move(char[][] map) {
        this.map = map;
        dinheiro = new Dinheiro();
    }
    public ArrayList<Integer> getList() {return dinheiro.getList();} 
    public int getDinheiro() {return dinheiro.getTotal();}

    public Direcao getDirection() {return direction;}
    public void setDirection(Direcao direction) {this.direction = direction;}
    
    public int getRow() {return row;}
    public void setRow(int row) {this.row = row;}

    public int getCol() {return col;}
    public void setCol(int col) {this.col = col;}

    public char[][] getMap() {return map;}
    public void setMap(char[][] map) {this.map = map;}

    public boolean isEnd() {return end;}
    public void setEnd(boolean end) {this.end = end;}

    public char getCurrentChar() {return currentChar;}
    public void setCurrentChar(char currentChar) {this.currentChar = currentChar;}


    public void findBegining(char[][] map) {        //Encontra o começo do percurso.
        for (int i = 1; i < map.length; i++) {      //Percorre apenas as linhas, já que sempre vai iniciar na primeira coluna (0).
            if (map[i][0] == '-') {                 //Busca o '-', que indica o ponto inicial.
                row = i;                            //Atualiza a variável 'row' para indicar a linha atual.
                direction = Direcao.RIGHT;          //Inicializa a direção a qual o carro se move como direita.
                currentChar = map[i][0];            //'currentChar' indica o caracter da posição atual em que o carro se encontra no mapa.
                break;
            }
        }
    }

    public void goDown() {                                          //Responsável por mover o carro para baixo.
        direction = Direcao.DOWN;                                   //Atualiza a direção do carro para baixo.
        if(currentChar == (char) 92 || currentChar == '/') {        //Avança uma posição, saindo da 'curva' que impedia o movimento inicial no loop.
            row++;                                                  
            currentChar = map[row][col];     
        }
        while (row < map.length && (currentChar == '-' || currentChar == '|' && !Character.isDigit(currentChar))) {          
            row++;                                                  //Se move enquanto percorrer caracteres válidos.
            currentChar = map[row][col];                            //Atualiza a posição atual através do 'currentChar' e 'row'. 
        }                                                           //O 'col', referente a coluna, não é atualizado pois o movimento é na vertical. 
    }

    public void goLeft() {                                          //Responsável por mover o carro para esquerda.
        direction = Direcao.LEFT;                                   //Atualiza a direção do carro para esquerda.
        if(currentChar == (char) 92 || currentChar == '/') {        //Avança uma posição, saindo da 'curva' que impedia o movimento inicial no loop.
            col--;                                                  
            currentChar = map[row][col];     
        }
        while (col >= 0 && (currentChar == '-' || currentChar == '|' && !Character.isDigit(currentChar))) {                  
            col--;                                                  //Se move enquanto percorrer caracteres válidos.
            currentChar = map[row][col];                            //Atualiza a posição atual através do 'currentChar' e 'col', 
        }                                                           //O 'row', referente a linha, não é atualizado pois o movimento é na horizontal.
    }

    public void goRight() {                                         //Responsável por mover o carro para direita.
        direction = Direcao.RIGHT;                                  //Atualiza a direção do carro para direita.
        if(currentChar == (char) 92 || currentChar == '/') {        //Avança uma posição, saindo da 'curva' que impedia o movimento inicial no loop.
            col++;                                                  
            currentChar = map[row][col];     
        }
        while (col < map[0].length && (currentChar == '-' || currentChar == '|' && !Character.isDigit(currentChar))) {    
            col++;                                                  //Se move enquanto percorrer caracteres válidos.
            currentChar = map[row][col];                            //Atualiza a posição atual através do 'currentChar' e 'col', 
        }                                                           //O 'row', referente a linha, não é atualizado pois o movimento é na horizontal.
    }   

    public void goUp() {                                            //Responsável por mover o carro para cima.
        direction = Direcao.UP;                                     //Atualiza a direção do carro para cima.
        if(currentChar == (char) 92 || currentChar == '/') {        //Avança uma posição, saindo da 'curva' que impedia o movimento inicial no loop.
            row--;                                                  
            currentChar = map[row][col];     
        }
        while (row >= 0 && (currentChar == '-' || currentChar == '|' && !Character.isDigit(currentChar))) {                 
            row--;                                                  //Se move enquanto percorrer caracteres válidos.
            currentChar = map[row][col];                            //Atualiza a posição atual através do 'currentChar' e 'row',
        }                                                           //O 'col', referente a coluna, não é atualizado pois o movimento é na vertical.
    }
    public int getNum(char place) {                                                     //Responsável por identificar e converter um número.
        int value = Character.getNumericValue(place);                                   //Transforma o char em int.
        switch (direction) {                                        
            case RIGHT:                                                         //Caso esteja se movendo para a direita, o ajuste é aumentando a coluna.
                int nextCol = col+1;
                while (nextCol < map[0].length && Character.isDigit(map[row][nextCol])) {       //Descobre se a próxima posição do mapa possui um numeral.
                    value = (value*10) + Character.getNumericValue(map[row][nextCol]);          //Multiplica o número anterior por 10 para o número recém lido se tornar a unidade.
                    nextCol++;     
                }    
                col = nextCol;                                                //Atualiza a posição o caracter atual.  
                currentChar = map[row][col];   
                break;
            
            case LEFT:                                                          //Caso esteja se movendo para a esquerda, o ajuste é diminuindo a coluna.
                int prevCol = col-1;
                while (prevCol >= 0 && Character.isDigit(map[row][prevCol])) {                  //Descobre se a próxima posição do mapa possui um numeral.
                    value = value * 10 + Character.getNumericValue(map[row][prevCol]);          //Multiplica o número anterior por 10 para o número recém lido se tornar a unidade.
                    prevCol--;
                }
                col = prevCol;
                currentChar = map[row][col];
                
                break;

            case UP:                                                            //Caso esteja se movendo para a esquerda, o ajuste é diminuindo a linha.
                int prevRow = row - 1;
                while (prevRow >= 0 && Character.isDigit(map[prevRow][col])) {                  //Descobre se a próxima posição do mapa possui um numeral.
                    value = value * 10 + Character.getNumericValue(map[prevRow][col]);          //Multiplica o número anterior por 10 para o número recém lido se tornar a unidade.
                    prevRow--;
                }
                row = prevRow;
                currentChar = map[row][col];
                
                break;
                
            case DOWN:                                                          //Caso esteja se movendo para baixo, o ajuste é aumentando a linha.
                int nextRow = row + 1;
                while (nextRow < map.length && Character.isDigit(map[nextRow][col])) {          //Descobre se a próxima posição do mapa possui um numeral.
                    value = value * 10 + Character.getNumericValue(map[nextRow][col]);          //Multiplica o número anterior por 10 para o número recém lido se tornar a unidade.
                    nextRow++;
                }
                row = nextRow;
                currentChar = map[row][col];
                
                break;
        }
        return value;
    }

    public void move() {                                        //Identifica o movimento que o carro deve fazer.   
        while(!end) {
            if(Character.isDigit(currentChar)) {                    //Reconhece se na posição atual há dinheiro à ser coletado.
                int num = getNum(currentChar);                      //Salva o número depois de ser tratado no método 'int getNum(char)'.
                dinheiro.store(num);                                //Utiliza o método 'store' da classe Dinheiro para guardar a quantia.
            }                    
            switch (currentChar) {                              //Switch para tratamento das curvas e fim do percurso.

                case '/':                                       //CASO 1: O caracter do mapa é '/' (barra).
                    if (direction == Direcao.LEFT) {            //A '/' indica uma curva, portanto, dependendo da direção atual, a curva deve ser para
                        goDown();                               //esquerda, cima ou baixo.
                    } else if (direction == Direcao.DOWN) {
                        goLeft();
                    } else if (direction == Direcao.RIGHT) {
                        goUp();
                    } else if (direction == Direcao.UP) {
                        goRight();
                    }
                    break;
        
                case (char) 92:                                 //CASO 2: O caracter do mapa é '\' (barra inversa).  
                    if (direction == Direcao.RIGHT) {           //Foi usado seu código ASCII (92) para representá-la pois com '', ela é utilizada para comentários,              
                        goDown();                               //inviabilizando o seu reconhecimento como char quando apresentada da seguinte forma: '\'.
                    } else if (direction == Direcao.DOWN) {     //A '\' indica uma curva, portanto, dependendo da direção atual, a curva deve ser para
                        goRight();                              //direita, cima ou baixo.
                    } else if (direction == Direcao.UP) {
                        goLeft();
                    } else if (direction == Direcao.LEFT){
                        goUp();
                    }
                    break;
                
                case '#':                                       //CASO 3: o caracter é '#' (cerquilha).
                    setEnd(true);                           //A '#' indica a posição final, portanto é o fim do mapa.
                    break;                                      //Assim, a varíavel boolean 'end' é definida para true, indicando o fim dos movimentos.        
            }
            
            if(currentChar == '-' || currentChar == '|') {  //Trecho referente ao movimento retilíneo.
                if(direction == Direcao.RIGHT) {            //O carro mantém o mesmo movimento até encontrar uma curva, dinheiro ou o fim do percurso.
                    goRight();
                } 
                else if(direction == Direcao.LEFT){
                    goLeft();
                }
                else if(direction == Direcao.DOWN) {
                    goDown();
                }
                else if(direction == Direcao.UP) {
                    goUp();
                }   
            } 
        }  
    }
}
