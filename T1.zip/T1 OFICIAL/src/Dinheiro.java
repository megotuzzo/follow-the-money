import java.util.*;

public class Dinheiro {

    private ArrayList<Integer> list;
    private int total;
    
    public Dinheiro() {
        list = new ArrayList<>();
    }

    public ArrayList<Integer> getList() {return list;}                 //A lista é responsável por guardar o dinheiro na ordem em que foi recolhido.
    public void setList(ArrayList<Integer> list) {this.list = list;}

    public int getTotal() {return total;}                               //O total é o somatório total do dinheiro recolhido.
    public void setTotal(int total) {this.total = total;}

    public void store (int value) {                     //Método responsável por gerenciar o dinheiro.
        list.add(value);                                //Adiciona a quantia recém identificada na lista.
        total = total + value;                          //Soma essa quantia ao total.
    }

}
