
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Mapa {
    private int row, col;
    private char[][] mapa;

    public Mapa() {    }

    public ArrayList<String> readLinesFromFile(String filePath) {
        ArrayList<String> lines = new ArrayList<>();
        try {
            File file = new File(filePath);
            Scanner scanner = new Scanner(file);
            
            String[] dimensions = scanner.nextLine().trim().split("\\s+");
            row = Integer.parseInt(dimensions[0]);
            col = Integer.parseInt(dimensions[1]);
            mapa = new char[row][col];

            // Lê o arquivo linha por linha e armazena em um ArrayList
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                lines.add(line);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo não encontrado.");
            e.printStackTrace();
        }
        return lines;
    }

    public char[][] toMatriz(ArrayList<String> array) {     //Transforma a String lida em uma matriz de caracteres.
        mapa = new char[row][col];
        for (int i = 0; i < row; i++) {
            char[] line = array.get(i).toCharArray();
            for (int j = 0; j < col; j++) {
                mapa[i][j] = line[j];
            }
        }
        return mapa;
    }
}