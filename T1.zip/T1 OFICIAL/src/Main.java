// Resolução do problema 'Siga o dinheiro' por Maria Eduarda Gotuzzo da Silva.

import java.util.*;
public class Main {
    public static void main(String[] args) {
        Mapa map = new Mapa();
        ArrayList<String> lines = map.readLinesFromFile("casoJ100.txt");
        char[][] mapa = map.toMatriz(lines);
        Move movimento = new Move(mapa);
   
/* 
        for (int i = 0; i < lines.size(); i++) {               //Impressão do mapa como matriz.
            for (int j = 0; j < lines.size(); j++) {
                if (j == lines.size() - 1) {
                    System.out.print("\n");
                }
                System.out.print(mapa[i][j]);
            }
        }
//*/
        movimento.findBegining(mapa);                   //Encontra o ponto inicial.
        movimento.move();                               //Inicia o movimento no mapa.
        System.out.println("Somatório do dinheiro recolhido: " + movimento.getDinheiro());
        //System.out.println("Ordem do dinheiro recolhido: " + movimento.getList());
        
    }
}
    