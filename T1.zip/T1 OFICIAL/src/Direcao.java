public enum Direcao {
    UP, DOWN, LEFT, RIGHT
}
